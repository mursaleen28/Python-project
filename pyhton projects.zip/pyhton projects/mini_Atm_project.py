import getpass

def authenticate():
    username = input("Enter your username: ")
    password = getpass.getpass("Enter your password: ")

    if username == "mursaleen" and password == "1234567":
        print("Authentication successful!")
        return True
    else:
        print("Incorrect username or password. Please try again.")
        return False

def check_balance():
    balance = 50000  # Assume initial balance is 50000
    print(f"Your current balance is pkr:{balance}")

def deposit():
    amount = int(input("Enter the amount to deposit: "))
    print(f"Deposited {amount} into your account")
    total_balance = 50000 + amount
    print("Now your total amount is", total_balance)

def withdraw():
    amount = int(input("Enter the amount to withdraw: "))
    if amount > 50000:
        print("Insufficient balance.")
    else:
        print(f"Withdrawing {amount}")
        total_balance = 50000 - amount
        print("Now your total amount is", total_balance)

def transfer():
    str_input = input("Do you want to transfer the amount? ")
    if str_input.lower() == 'yes':
        account = input("Please provide the account number of the recipient: ")
        amount = int(input("Enter the amount that you want to transfer: "))
        print("Transferring", amount, "to account", account)
        # Perform the transfer operation here
        print("Transfer successful!")
    else:
        print("Transfer cancelled.")

def main():
    authenticated = False
    while not authenticated:
        authenticated = authenticate()

    # Once authenticated, allow the user to perform account-related operations
    check_balance()
    deposit()
    withdraw()
    transfer()

    print("**** THANK YOU! ****")

if __name__ == "__main__":
    main()
