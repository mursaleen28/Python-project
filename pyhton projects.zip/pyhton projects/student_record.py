import tkinter as tk
from tkinter import simpledialog, messagebox

root = tk.Tk()
root.title("Form")
root.geometry('350x200')

records = []

def add_record():
    username = simpledialog.askstring("Input", "Enter username:")
    if username:
        user_id = simpledialog.askstring("Input", "Enter ID:")
        if user_id:
            batch = simpledialog.askinteger("Input", "Enter batch:")
            if batch:
                department = simpledialog.askstring("Input", "Enter department:")
                if department:
                    gpa = simpledialog.askfloat("Input", "Enter GPA:")
                    if gpa:
                        record = {
                            "Username": username,
                            "ID": user_id,
                            "Batch": batch,
                            "Department": department,
                            "GPA": gpa
                        }
                        records.append(record)
                        save_data()  # Save the data to a file
                        messagebox.showinfo("Success", "Record added successfully!")

def save_data():
    if records:
        with open('data.txt', 'w') as file:
            for record in records:
                file.write(f"Username: {record['Username']}\nID: {record['ID']}\nBatch: {record['Batch']}\nDepartment: {record['Department']}\nGPA: {record['GPA']}\n\n")
        lbl.configure(text="Data saved successfully!")

def show_records():
    if not records:
        messagebox.showinfo("No Records", "No records found.")
    else:
        record_window = tk.Toplevel(root)
        record_window.title("Records")
        record_text = ""
        for record in records:
            record_text += f"Username: {record['Username']}\nID: {record['ID']}\nBatch: {record['Batch']}\nDepartment: {record['Department']}\nGPA: {record['GPA']}\n\n"
        records_label = tk.Label(record_window, text=record_text, justify="left")
        records_label.pack()

def delete_record():
    if not records:
        messagebox.showinfo("No Records", "No records to delete.")
    else:
        username = simpledialog.askstring("Delete Record", "Enter the username to delete:")
        if username:
            found_records = [record for record in records if record['Username'] == username]
            if found_records:
                for record in found_records:
                    records.remove(record)
                save_data()  # Save the updated data to a file
                messagebox.showinfo("Success", "Record has been deleted.")
            else:
                messagebox.showinfo("Not Found", "Username not found.")

welcome_label = tk.Label(root, text="Welcome to NAVTTC")
welcome_label.pack()

btn_add_record = tk.Button(root, text="Add record", fg="blue", command=add_record)
btn_add_record.pack()

btn_show_record = tk.Button(root, text="Show record", fg="green", command=show_records)
btn_show_record.pack()

btn_delete_record = tk.Button(root, text="Delete record", fg="red", command=delete_record)
btn_delete_record.pack()

lbl = tk.Label(root, text="")
lbl.pack()

root.mainloop()
