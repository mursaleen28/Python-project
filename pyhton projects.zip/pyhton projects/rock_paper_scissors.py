import tkinter as tk
from tkinter import messagebox
import random

def get_computer_choice():
    return random.choice(["Rock", "Paper", "Scissors"])

def play_game(user_choice):
    computer_choice = get_computer_choice()

    result = ""
    if user_choice == computer_choice:
        result = "It's a tie!"
    elif (user_choice == "Rock" and computer_choice == "Scissors") or \
         (user_choice == "Scissors" and computer_choice == "Paper") or \
         (user_choice == "Paper" and computer_choice == "Rock"):
        result = "You win!"
    else:
        result = "You lose!"

    return f"Computer chose {computer_choice}. {result}"

def on_button_click(choice):
    result_label.config(text=play_game(choice))
    messagebox.showinfo("Result", result_label.cget("text"))

if __name__ == "__main__":
    root = tk.Tk()
    root.title("Rock, Paper, Scissors Game")
    root.geometry("400x300")
    root.config(bg="#F7C6C5")

    title_label = tk.Label(root, text="Rock, Paper, Scissors", font=("Arial", 20), bg="#F7C6C5")
    title_label.pack(pady=20)

    buttons_frame = tk.Frame(root, bg="#F7C6C5")
    buttons_frame.pack()

    rock_button = tk.Button(buttons_frame, text="Rock", font=("Arial", 16), bg="#FF6F61", command=lambda: on_button_click("Rock"))
    rock_button.pack(side=tk.LEFT, padx=10)

    paper_button = tk.Button(buttons_frame, text="Paper", font=("Arial", 16), bg="#FFA07A", command=lambda: on_button_click("Paper"))
    paper_button.pack(side=tk.LEFT, padx=10)

    scissors_button = tk.Button(buttons_frame, text="Scissors", font=("Arial", 16), bg="#98FB98", command=lambda: on_button_click("Scissors"))
    scissors_button.pack(side=tk.LEFT, padx=10)

    result_label = tk.Label(root, text="", font=("Arial", 18), bg="#F7C6C5")
    result_label.pack(pady=20)

    root.mainloop()
